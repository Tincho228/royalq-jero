<div class="container-fluid bg-fourth-color">
    <div class="row justify-content-center" style="padding:30px 0px;">
        <div class="col-sm-12 col-lg-8">
            <div>
                <p class="text-light text-center" style="margin:0px">2021 Todos los derechos reservados</p>
                <p class="text-light text-center" style="margin:0px"><img src="./images/btcjero.png" alt="Logo Btc jero"
                        style="width: 30px;">
                    ROYALQ-BTCJERO.COM</p>
            </div>
        </div>
    </div>
</div>